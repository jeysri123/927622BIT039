import React, { useRef } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Scatter } from 'react-chartjs-2';
import { CorrelationData, StockPriceHistory } from '../types';
import { calculateAverage, calculateStandardDeviation } from '../utils/calculations';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  Title,
  Tooltip,
  Legend
);

interface HeatmapProps {
  correlationData: CorrelationData[];
  stocksData: StockPriceHistory[];
}

const CorrelationHeatmap: React.FC<HeatmapProps> = ({ correlationData, stocksData }) => {
  const chartRef = useRef(null);
  
  const uniqueStocks = Array.from(new Set(
    correlationData.flatMap(item => [item.stockA, item.stockB])
  )).sort();
  
  // Create a 2D array for the heatmap data
  const heatmapData = Array(uniqueStocks.length).fill(0).map(() => 
    Array(uniqueStocks.length).fill(0)
  );
  
  // Fill the heatmap data
  correlationData.forEach(item => {
    const indexA = uniqueStocks.indexOf(item.stockA);
    const indexB = uniqueStocks.indexOf(item.stockB);
    
    if (indexA >= 0 && indexB >= 0) {
      heatmapData[indexA][indexB] = item.correlation;
      // Mirror for symmetry
      heatmapData[indexB][indexA] = item.correlation;
    }
  });
  
  // Fill diagonal with 1 (self-correlation)
  for (let i = 0; i < uniqueStocks.length; i++) {
    heatmapData[i][i] = 1;
  }
  
  // Convert to ChartJS dataset
  const datasets = [];
  
  for (let i = 0; i < uniqueStocks.length; i++) {
    for (let j = 0; j < uniqueStocks.length; j++) {
      const color = getColorForCorrelation(heatmapData[i][j]);
      
      datasets.push({
        label: `${uniqueStocks[i]} vs ${uniqueStocks[j]}`,
        data: [{x: j, y: uniqueStocks.length - 1 - i}],
        backgroundColor: color,
        borderColor: 'rgba(0,0,0,0.1)',
        borderWidth: 1,
        pointRadius: 20,
        pointHoverRadius: 20,
      });
    }
  }
  
  // ChartJS data
  const data = {
    datasets,
  };
  
  // Get stock data for tooltip
  const getStockData = (ticker: string) => {
    return stocksData.find(stock => stock.ticker === ticker);
  };
  
  // ChartJS options
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      x: {
        type: 'linear' as const,
        position: 'bottom' as const,
        min: -0.5,
        max: uniqueStocks.length - 0.5,
        ticks: {
          callback: function(value: number) {
            return uniqueStocks[value] || '';
          },
          stepSize: 1,
        },
        grid: {
          display: false,
        },
      },
      y: {
        type: 'linear' as const,
        min: -0.5,
        max: uniqueStocks.length - 0.5,
        ticks: {
          callback: function(value: number) {
            return uniqueStocks[uniqueStocks.length - 1 - value] || '';
          },
          stepSize: 1,
        },
        grid: {
          display: false,
        },
      },
    },
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          title: function(context: any) {
            if (context.length > 0) {
              const dataIndex = context[0].dataIndex;
              const datasetIndex = context[0].datasetIndex;
              const i = Math.floor(datasetIndex / uniqueStocks.length);
              const j = datasetIndex % uniqueStocks.length;
              
              const stockA = uniqueStocks[i];
              const stockB = uniqueStocks[j];
              const correlation = heatmapData[i][j];
              
              return `Correlation: ${correlation.toFixed(3)}`;
            }
            return '';
          },
          label: function(context: any) {
            const datasetIndex = context.datasetIndex;
            const i = Math.floor(datasetIndex / uniqueStocks.length);
            const j = datasetIndex % uniqueStocks.length;
            
            const stockA = uniqueStocks[i];
            const stockB = uniqueStocks[j];
            
            // Get stock data for additional information
            const stockDataA = getStockData(stockA);
            const stockDataB = getStockData(stockB);
            
            const labels = [];
            
            labels.push(`${stockA} vs ${stockB}`);
            
            if (stockDataA) {
              const avgA = calculateAverage(stockDataA.prices);
              const stdDevA = calculateStandardDeviation(stockDataA.prices);
              labels.push(`${stockA} Avg: $${avgA.toFixed(2)}`);
              labels.push(`${stockA} StdDev: $${stdDevA.toFixed(2)}`);
            }
            
            if (stockDataB) {
              const avgB = calculateAverage(stockDataB.prices);
              const stdDevB = calculateStandardDeviation(stockDataB.prices);
              labels.push(`${stockB} Avg: $${avgB.toFixed(2)}`);
              labels.push(`${stockB} StdDev: $${stdDevB.toFixed(2)}`);
            }
            
            return labels;
          },
        },
      },
    },
  };
  
  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <h2 className="text-xl font-bold mb-4 text-center">Stock Correlation Heatmap</h2>
      <div className="flex justify-center mb-4">
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-blue-700 rounded"></div>
          <span>High Positive</span>
        </div>
        <div className="mx-4">-</div>
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-gray-200 rounded"></div>
          <span>No Correlation</span>
        </div>
        <div className="mx-4">-</div>
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-red-700 rounded"></div>
          <span>High Negative</span>
        </div>
      </div>
      <div className="h-[600px]">
        <Scatter ref={chartRef} data={data} options={options} />
      </div>
    </div>
  );
};

// Helper function to get color based on correlation value
function getColorForCorrelation(correlation: number): string {
  // Handle NaN values
  if (isNaN(correlation)) {
    return 'rgba(200, 200, 200, 0.7)';
  }
  
  // For positive correlation (0 to 1): Blue gradient
  if (correlation >= 0) {
    const intensity = correlation;
    return `rgba(37, 99, 235, ${intensity})`;
  } 
  // For negative correlation (-1 to 0): Red gradient
  else {
    const intensity = Math.abs(correlation);
    return `rgba(220, 38, 38, ${intensity})`;
  }
}

export default CorrelationHeatmap;