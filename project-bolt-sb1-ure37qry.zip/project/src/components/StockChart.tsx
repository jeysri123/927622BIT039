import React, { useRef } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ChartOptions,
} from 'chart.js';
import { formatDate } from '../utils/calculations';
import { StockPrice } from '../types';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface StockChartProps {
  stockName: string;
  ticker: string;
  prices: StockPrice[];
  average: number;
}

const StockChart: React.FC<StockChartProps> = ({ 
  stockName, 
  ticker, 
  prices, 
  average 
}) => {
  const chartRef = useRef(null);

  // Format dates for x-axis
  const labels = prices.map(price => {
    const date = new Date(price.lastUpdatedAt);
    return date.toLocaleTimeString();
  });

  // Prepare data for the chart
  const data = {
    labels,
    datasets: [
      {
        label: `${ticker} Price`,
        data: prices.map(price => price.price),
        borderColor: 'rgb(37, 99, 235)',
        backgroundColor: 'rgba(37, 99, 235, 0.5)',
        tension: 0.3,
      },
      {
        label: 'Average',
        data: Array(prices.length).fill(average),
        borderColor: 'rgb(220, 38, 38)',
        backgroundColor: 'rgba(220, 38, 38, 0.5)',
        borderDash: [5, 5],
        tension: 0,
      },
    ],
  };

  // Chart options
  const options: ChartOptions<'line'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: `${stockName} (${ticker}) Price History`,
        font: {
          size: 16,
          weight: 'bold',
        },
      },
      tooltip: {
        mode: 'index',
        intersect: false,
        callbacks: {
          label: function(context) {
            if (context.dataset.label === 'Average') {
              return `Average: $${context.parsed.y.toFixed(2)}`;
            }
            return `Price: $${context.parsed.y.toFixed(2)}`;
          },
          title: function(context) {
            if (context.length > 0) {
              const index = context[0].dataIndex;
              return formatDate(prices[index].lastUpdatedAt);
            }
            return '';
          },
        },
      },
    },
    scales: {
      y: {
        title: {
          display: true,
          text: 'Price ($)',
        },
        ticks: {
          callback: function(value) {
            return '$' + value;
          },
        },
      },
      x: {
        title: {
          display: true,
          text: 'Time',
        },
      },
    },
    interaction: {
      mode: 'nearest',
      axis: 'x',
      intersect: false,
    },
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <div className="h-[400px]">
        <Line ref={chartRef} data={data} options={options} />
      </div>
    </div>
  );
};

export default StockChart;