import React, { useState, useEffect } from 'react';
import { Search } from 'lucide-react';
import { Stock } from '../types';

interface StockSelectorProps {
  stocks: Stock[];
  selectedStock: Stock | null;
  onSelectStock: (stock: Stock) => void;
}

const StockSelector: React.FC<StockSelectorProps> = ({ 
  stocks, 
  selectedStock, 
  onSelectStock 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredStocks, setFilteredStocks] = useState<Stock[]>(stocks);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  // Filter stocks when search term or stocks change
  useEffect(() => {
    if (searchTerm.trim() === '') {
      setFilteredStocks(stocks);
    } else {
      const filtered = stocks.filter(
        stock => 
          stock.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
          stock.ticker.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredStocks(filtered);
    }
  }, [searchTerm, stocks]);

  return (
    <div className="relative mb-4">
      <div className="flex items-center">
        <label className="font-medium text-gray-700 mr-4 min-w-max">Select Stock:</label>
        <div className="relative flex-grow">
          <div 
            className="flex items-center border border-gray-300 rounded-md p-2 w-full cursor-pointer bg-white"
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
          >
            <div className="flex-grow">
              {selectedStock ? (
                <div className="flex justify-between items-center">
                  <span>{selectedStock.name}</span>
                  <span className="text-blue-700 font-bold">{selectedStock.ticker}</span>
                </div>
              ) : (
                <span className="text-gray-500">Select a stock...</span>
              )}
            </div>
          </div>
          
          {isDropdownOpen && (
            <div className="absolute z-10 mt-1 w-full bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-auto">
              <div className="sticky top-0 bg-white p-2 border-b">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                  <input
                    type="text"
                    placeholder="Search stocks..."
                    className="w-full p-2 pl-9 border border-gray-300 rounded-md"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    onClick={(e) => e.stopPropagation()}
                  />
                </div>
              </div>
              
              {filteredStocks.length > 0 ? (
                filteredStocks.map((stock, index) => (
                  <div
                    key={stock.ticker}
                    className={`p-2 hover:bg-blue-50 cursor-pointer ${
                      index !== filteredStocks.length - 1 ? 'border-b border-gray-100' : ''
                    }`}
                    onClick={() => {
                      onSelectStock(stock);
                      setIsDropdownOpen(false);
                      setSearchTerm('');
                    }}
                  >
                    <div className="flex justify-between items-center">
                      <span>{stock.name}</span>
                      <span className="text-blue-700 font-bold">{stock.ticker}</span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-4 text-center text-gray-500">No stocks found</div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StockSelector;