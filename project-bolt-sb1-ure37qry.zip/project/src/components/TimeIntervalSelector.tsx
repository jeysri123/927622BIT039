import React from 'react';

interface TimeIntervalSelectorProps {
  minutes: number;
  onChange: (minutes: number) => void;
}

const TimeIntervalSelector: React.FC<TimeIntervalSelectorProps> = ({ minutes, onChange }) => {
  const intervals = [5, 15, 30, 60, 120, 240];
  
  return (
    <div className="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-4 mb-4">
      <label className="font-medium text-gray-700 min-w-max">Time Interval:</label>
      <div className="flex flex-wrap gap-2">
        {intervals.map((interval) => (
          <button
            key={interval}
            onClick={() => onChange(interval)}
            className={`px-4 py-2 rounded-md transition-colors ${
              minutes === interval
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
            }`}
          >
            {interval} min
          </button>
        ))}
      </div>
    </div>
  );
};

export default TimeIntervalSelector;