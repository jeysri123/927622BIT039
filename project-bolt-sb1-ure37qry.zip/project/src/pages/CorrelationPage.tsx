import React, { useState, useEffect, useCallback } from 'react';
import TimeIntervalSelector from '../components/TimeIntervalSelector';
import CorrelationHeatmap from '../components/CorrelationHeatmap';
import { getStocks, getStockPriceHistory, getAuthToken } from '../services/api';
import { Stock, StockPrice, CorrelationData, StockPriceHistory } from '../types';
import { calculateCorrelation } from '../utils/calculations';
import { RefreshCw } from 'lucide-react';

const CorrelationPage: React.FC = () => {
  const [stocks, setStocks] = useState<Stock[]>([]);
  const [minutes, setMinutes] = useState<number>(30);
  const [stocksData, setStocksData] = useState<StockPriceHistory[]>([]);
  const [correlationData, setCorrelationData] = useState<CorrelationData[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [selectedStocks, setSelectedStocks] = useState<string[]>([]);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

  // Handle authentication first
  useEffect(() => {
    const authenticate = async () => {
      try {
        setLoading(true);
        // Use the same credentials as in StockPage
        const credentials = {
          email: "student@example.com",
          name: "Student Name",
          rollNo: "123",
          accessCode: "access123",
          clientID: "client123",
          clientSecret: "secret123"
        };

        await getAuthToken(credentials);
        setIsAuthenticated(true);
        setLoading(false);
      } catch (err) {
        setError('Authentication failed. Please check your credentials.');
        setLoading(false);
      }
    };

    authenticate();
  }, []);

  // Fetch stocks only after authentication
  useEffect(() => {
    const fetchStocks = async () => {
      if (!isAuthenticated) return;

      try {
        setLoading(true);
        const stocksData = await getStocks();
        
        // Convert to array of Stock objects
        const stocksArray = Object.entries(stocksData).map(([name, ticker]) => ({
          name,
          ticker: ticker as string,
        }));
        
        setStocks(stocksArray);
        
        // By default, select first 5 stocks (or all if less than 5)
        const initialSelectedStocks = stocksArray
          .slice(0, Math.min(5, stocksArray.length))
          .map(stock => stock.ticker);
        
        setSelectedStocks(initialSelectedStocks);
        
        setLoading(false);
      } catch (err) {
        setError('Failed to fetch stocks. Please try again later.');
        setLoading(false);
      }
    };
    
    fetchStocks();
  }, [isAuthenticated]);

  // Fetch price history for selected stocks
  const fetchAllPriceHistories = useCallback(async () => {
    if (selectedStocks.length === 0 || !isAuthenticated) return;
    
    try {
      setLoading(true);
      
      // Fetch price history for each selected stock
      const promises = selectedStocks.map(async (ticker) => {
        try {
          const priceHistory = await getStockPriceHistory(ticker, minutes);
          return {
            ticker,
            prices: priceHistory,
          };
        } catch (error) {
          console.error(`Error fetching price history for ${ticker}:`, error);
          return {
            ticker,
            prices: [],
          };
        }
      });
      
      const allStocksData = await Promise.all(promises);
      setStocksData(allStocksData);
      
      // Calculate correlations between all pairs of stocks
      const correlations: CorrelationData[] = [];
      
      for (let i = 0; i < allStocksData.length; i++) {
        for (let j = i + 1; j < allStocksData.length; j++) {
          const stockA = allStocksData[i];
          const stockB = allStocksData[j];
          
          // Only calculate if both stocks have data
          if (stockA.prices.length > 0 && stockB.prices.length > 0) {
            // Ensure equal length for correlation calculation
            const minLength = Math.min(stockA.prices.length, stockB.prices.length);
            const pricesA = stockA.prices.slice(0, minLength);
            const pricesB = stockB.prices.slice(0, minLength);
            
            const correlation = calculateCorrelation(pricesA, pricesB);
            
            correlations.push({
              stockA: stockA.ticker,
              stockB: stockB.ticker,
              correlation,
            });
          }
        }
      }
      
      setCorrelationData(correlations);
      setLastUpdated(new Date());
      setLoading(false);
    } catch (err) {
      setError('Failed to fetch price histories. Please try again later.');
      setLoading(false);
    }
  }, [selectedStocks, minutes, isAuthenticated]);

  useEffect(() => {
    if (selectedStocks.length > 0 && isAuthenticated) {
      fetchAllPriceHistories();
    }
  }, [selectedStocks, minutes, fetchAllPriceHistories, isAuthenticated]);

  const handleMinutesChange = (newMinutes: number) => {
    setMinutes(newMinutes);
  };

  const handleRefresh = () => {
    fetchAllPriceHistories();
  };

  const toggleStockSelection = (ticker: string) => {
    setSelectedStocks(prev => {
      if (prev.includes(ticker)) {
        return prev.filter(t => t !== ticker);
      } else {
        return [...prev, ticker];
      }
    });
  };

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
          <h1 className="text-2xl font-bold mb-2 md:mb-0">Stock Correlation Analysis</h1>
          
          <div className="flex items-center">
            <button
              onClick={handleRefresh}
              className="flex items-center space-x-1 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
              disabled={loading || !isAuthenticated}
            >
              <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
              <span>Refresh Data</span>
            </button>
            
            {lastUpdated && (
              <span className="ml-4 text-sm text-gray-500">
                Last updated: {lastUpdated.toLocaleTimeString()}
              </span>
            )}
          </div>
        </div>

        <div className="bg-blue-50 p-4 rounded-lg mb-6">
          <div className="mb-4">
            <label className="font-medium text-gray-700 block mb-2">Select Stocks to Compare:</label>
            <div className="flex flex-wrap gap-2">
              {stocks.map((stock) => (
                <button
                  key={stock.ticker}
                  onClick={() => toggleStockSelection(stock.ticker)}
                  className={`px-3 py-1 rounded-md text-sm transition-colors ${
                    selectedStocks.includes(stock.ticker)
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
                  }`}
                >
                  {stock.ticker}
                </button>
              ))}
            </div>
          </div>
          
          <TimeIntervalSelector
            minutes={minutes}
            onChange={handleMinutesChange}
          />
        </div>

        {error && (
          <div className="bg-red-100 text-red-700 p-4 rounded-lg mb-6">
            {error}
          </div>
        )}

        {loading && !error ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
          </div>
        ) : correlationData.length > 0 ? (
          <CorrelationHeatmap
            correlationData={correlationData}
            stocksData={stocksData}
          />
        ) : (
          <div className="text-center p-8 bg-gray-50 rounded-lg">
            {!isAuthenticated ? 'Authenticating...' :
              selectedStocks.length > 0 
                ? 'No correlation data available for the selected stocks and time interval.' 
                : 'Please select at least two stocks to view correlation data.'}
          </div>
        )}
      </div>
    </div>
  );
};

export default CorrelationPage;