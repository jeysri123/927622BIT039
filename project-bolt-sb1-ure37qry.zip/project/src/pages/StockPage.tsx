import React, { useState, useEffect, useCallback } from 'react';
import StockSelector from '../components/StockSelector';
import TimeIntervalSelector from '../components/TimeIntervalSelector';
import StockChart from '../components/StockChart';
import { getStocks, getStockPriceHistory, getAuthToken } from '../services/api';
import { Stock, StockPrice } from '../types';
import { calculateAverage } from '../utils/calculations';
import { RefreshCw } from 'lucide-react';

const StockPage: React.FC = () => {
  const [stocks, setStocks] = useState<Stock[]>([]);
  const [selectedStock, setSelectedStock] = useState<Stock | null>(null);
  const [minutes, setMinutes] = useState<number>(30);
  const [prices, setPrices] = useState<StockPrice[]>([]);
  const [average, setAverage] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

  // Handle authentication first
  useEffect(() => {
    const authenticate = async () => {
      try {
        setLoading(true);
        // Replace these values with your actual credentials
        const credentials = {
          email: "student@example.com",
          name: "Student Name",
          rollNo: "123",
          accessCode: "access123",
          clientID: "client123",
          clientSecret: "secret123"
        };

        await getAuthToken(credentials);
        setIsAuthenticated(true);
        setLoading(false);
      } catch (err) {
        setError('Authentication failed. Please check your credentials.');
        setLoading(false);
      }
    };

    authenticate();
  }, []);

  // Fetch stocks only after authentication
  useEffect(() => {
    const fetchStocks = async () => {
      if (!isAuthenticated) return;

      try {
        setLoading(true);
        const stocksData = await getStocks();
        
        // Convert to array of Stock objects
        const stocksArray = Object.entries(stocksData).map(([name, ticker]) => ({
          name,
          ticker: ticker as string,
        }));
        
        setStocks(stocksArray);
        
        // Set a default selected stock if available
        if (stocksArray.length > 0) {
          setSelectedStock(stocksArray[0]);
        }
        
        setLoading(false);
      } catch (err) {
        setError('Failed to fetch stocks. Please try again later.');
        setLoading(false);
      }
    };
    
    fetchStocks();
  }, [isAuthenticated]);

  // Fetch price history when selected stock or minutes change
  const fetchPriceHistory = useCallback(async () => {
    if (!selectedStock || !isAuthenticated) return;
    
    try {
      setLoading(true);
      const priceHistory = await getStockPriceHistory(selectedStock.ticker, minutes);
      setPrices(priceHistory);
      
      // Calculate average
      const avg = calculateAverage(priceHistory);
      setAverage(avg);
      
      setLastUpdated(new Date());
      setLoading(false);
    } catch (err) {
      setError(`Failed to fetch price history for ${selectedStock.ticker}. Please try again later.`);
      setLoading(false);
    }
  }, [selectedStock, minutes, isAuthenticated]);

  useEffect(() => {
    if (selectedStock && isAuthenticated) {
      fetchPriceHistory();
    }
  }, [selectedStock, minutes, fetchPriceHistory, isAuthenticated]);

  const handleStockSelect = (stock: Stock) => {
    setSelectedStock(stock);
  };

  const handleMinutesChange = (newMinutes: number) => {
    setMinutes(newMinutes);
  };

  const handleRefresh = () => {
    fetchPriceHistory();
  };

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
          <h1 className="text-2xl font-bold mb-2 md:mb-0">Stock Price Analysis</h1>
          
          <div className="flex items-center">
            <button
              onClick={handleRefresh}
              className="flex items-center space-x-1 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
              disabled={loading || !isAuthenticated}
            >
              <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
              <span>Refresh Data</span>
            </button>
            
            {lastUpdated && (
              <span className="ml-4 text-sm text-gray-500">
                Last updated: {lastUpdated.toLocaleTimeString()}
              </span>
            )}
          </div>
        </div>

        <div className="bg-blue-50 p-4 rounded-lg mb-6">
          <StockSelector
            stocks={stocks}
            selectedStock={selectedStock}
            onSelectStock={handleStockSelect}
          />
          
          <TimeIntervalSelector
            minutes={minutes}
            onChange={handleMinutesChange}
          />
        </div>

        {error && (
          <div className="bg-red-100 text-red-700 p-4 rounded-lg mb-6">
            {error}
          </div>
        )}

        {loading && !error ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
          </div>
        ) : selectedStock && prices.length > 0 ? (
          <StockChart
            stockName={selectedStock.name}
            ticker={selectedStock.ticker}
            prices={prices}
            average={average}
          />
        ) : (
          <div className="text-center p-8 bg-gray-50 rounded-lg">
            {!isAuthenticated ? 'Authenticating...' : 
              selectedStock ? 'No price data available for the selected time interval.' : 'Please select a stock to view its price history.'}
          </div>
        )}
      </div>
    </div>
  );
};

export default StockPage;