import axios from 'axios';
import { Stock, StockPrice } from '../types';

// Update to use HTTPS for the production environment
const BASE_URL = 'https://20.244.56.144/evaluation-service';

// Configure axios with your authorization token
let token = '';

export const setAuthToken = (newToken: string) => {
  token = newToken;
  axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
};

// Function to get authentication token
export const getAuthToken = async (credentials: {
  email: string;
  name: string;
  rollNo: string;
  accessCode: string;
  clientID: string;
  clientSecret: string;
}) => {
  try {
    // Configure axios for this specific request
    const config = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      // Allow self-signed certificates in development
      httpsAgent: new (await import('https')).Agent({
        rejectUnauthorized: false
      })
    };

    const response = await axios.post(`${BASE_URL}/auth`, credentials, config);
    const { access_token } = response.data;
    setAuthToken(access_token);
    return access_token;
  } catch (error) {
    // Provide more detailed error information
    if (axios.isAxiosError(error)) {
      if (error.response) {
        // The server responded with a status code outside of 2xx
        throw new Error(`Authentication failed: ${error.response.status} - ${JSON.stringify(error.response.data)}`);
      } else if (error.request) {
        // The request was made but no response was received
        throw new Error('Unable to reach authentication server. Please check your network connection and try again.');
      } else {
        // Something happened in setting up the request
        throw new Error(`Authentication error: ${error.message}`);
      }
    } else {
      throw new Error('An unexpected error occurred during authentication.');
    }
  }
};

// Function to ensure we have a valid auth token
const ensureAuth = async () => {
  if (!token) {
    throw new Error('Authentication token not set. Please call getAuthToken first.');
  }
};

// Function to get all stocks
export const getStocks = async (): Promise<Record<string, string>> => {
  try {
    await ensureAuth();
    const config = {
      // Allow self-signed certificates in development
      httpsAgent: new (await import('https')).Agent({
        rejectUnauthorized: false
      })
    };
    const response = await axios.get(`${BASE_URL}/stocks`, config);
    return response.data.stocks;
  } catch (error) {
    if (error.message === 'Authentication token not set. Please call getAuthToken first.') {
      console.error('Authentication error:', error.message);
    } else {
      console.error('Error fetching stocks:', error);
    }
    throw error;
  }
};

// Function to get a specific stock's current price
export const getStockPrice = async (ticker: string): Promise<StockPrice> => {
  try {
    await ensureAuth();
    const config = {
      // Allow self-signed certificates in development
      httpsAgent: new (await import('https')).Agent({
        rejectUnauthorized: false
      })
    };
    const response = await axios.get(`${BASE_URL}/stocks/${ticker}`, config);
    return response.data.stock;
  } catch (error) {
    console.error(`Error fetching price for ${ticker}:`, error);
    throw error;
  }
};

// Function to get a stock's price history
export const getStockPriceHistory = async (ticker: string, minutes: number): Promise<StockPrice[]> => {
  try {
    await ensureAuth();
    const config = {
      // Allow self-signed certificates in development
      httpsAgent: new (await import('https')).Agent({
        rejectUnauthorized: false
      })
    };
    const response = await axios.get(`${BASE_URL}/stocks/${ticker}?minutes=${minutes}`, config);
    return Array.isArray(response.data) ? response.data : [];
  } catch (error) {
    console.error(`Error fetching price history for ${ticker}:`, error);
    throw error;
  }
};