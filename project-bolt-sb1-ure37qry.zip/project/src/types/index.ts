export interface Stock {
  name: string;
  ticker: string;
}

export interface StockPrice {
  price: number;
  lastUpdatedAt: string;
}

export interface StockPriceHistory {
  ticker: string;
  prices: StockPrice[];
  average?: number;
}

export interface CorrelationData {
  stockA: string;
  stockB: string;
  correlation: number;
}