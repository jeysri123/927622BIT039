import { StockPrice } from '../types';

// Calculate average price from stock price history
export const calculateAverage = (prices: StockPrice[]): number => {
  if (prices.length === 0) return 0;
  
  const sum = prices.reduce((acc, current) => acc + current.price, 0);
  return sum / prices.length;
};

// Calculate standard deviation from stock price history
export const calculateStandardDeviation = (prices: StockPrice[]): number => {
  if (prices.length === 0) return 0;
  
  const avg = calculateAverage(prices);
  const squareDiffs = prices.map(price => Math.pow(price.price - avg, 2));
  const avgSquareDiff = squareDiffs.reduce((acc, val) => acc + val, 0) / prices.length;
  return Math.sqrt(avgSquareDiff);
};

// Calculate correlation between two series of stock prices
export const calculateCorrelation = (pricesA: StockPrice[], pricesB: StockPrice[]): number => {
  if (pricesA.length === 0 || pricesB.length === 0 || pricesA.length !== pricesB.length) {
    return 0;
  }

  const n = pricesA.length;
  
  // Calculate means
  const meanA = calculateAverage(pricesA);
  const meanB = calculateAverage(pricesB);
  
  // Calculate sum of products of deviations
  let sumProductDeviations = 0;
  let sumSquareDeviationsA = 0;
  let sumSquareDeviationsB = 0;
  
  for (let i = 0; i < n; i++) {
    const deviationA = pricesA[i].price - meanA;
    const deviationB = pricesB[i].price - meanB;
    
    sumProductDeviations += deviationA * deviationB;
    sumSquareDeviationsA += deviationA * deviationA;
    sumSquareDeviationsB += deviationB * deviationB;
  }
  
  // Calculate correlation coefficient
  if (sumSquareDeviationsA === 0 || sumSquareDeviationsB === 0) {
    return 0;
  }
  
  return sumProductDeviations / (Math.sqrt(sumSquareDeviationsA) * Math.sqrt(sumSquareDeviationsB));
};

// Format date for display
export const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  return date.toLocaleString();
};